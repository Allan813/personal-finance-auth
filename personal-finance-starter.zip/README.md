# Personal Finance — Next.js Starter

**Stack:** Next.js (App Router) + Tailwind + Recharts + Supabase (opcional) + importador CSV.

## Rodar local
```bash
npm i
cp .env.example .env.local  # pode deixar vazio para usar localStorage
npm run dev
```

Acesse http://localhost:3000/dashboard

## Deploy (Vercel)
1. Crie um repositório no GitHub e suba o código.
2. Importe o repo no Vercel.
3. (Opcional) Adicione `NEXT_PUBLIC_SUPABASE_URL` e `NEXT_PUBLIC_SUPABASE_ANON_KEY` em Project Settings → Environment Variables.
4. Deploy.
