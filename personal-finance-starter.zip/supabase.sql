create table if not exists transactions (
  id uuid primary key default gen_random_uuid(),
  date date not null,
  amount numeric not null,
  description text,
  category text,
  type text check (type in ('income','expense')) not null,
  inserted_at timestamp with time zone default now()
);

create table if not exists bills (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  amount numeric not null,
  due_day int not null,
  category text,
  autopay boolean default false,
  inserted_at timestamp with time zone default now()
);

create table if not exists budgets (
  id uuid primary key default gen_random_uuid(),
  month text not null,
  category text not null,
  planned_amount numeric not null,
  inserted_at timestamp with time zone default now(),
  unique(month, category)
);

create table if not exists goals (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  target numeric not null,
  saved numeric not null,
  deadline text,
  inserted_at timestamp with time zone default now()
);

alter table transactions enable row level security;
alter table bills enable row level security;
alter table budgets enable row level security;
alter table goals enable row level security;

create policy "anon read" on transactions for select using (true);
create policy "anon write" on transactions for insert with check (true);
create policy "anon read" on bills for select using (true);
create policy "anon write" on bills for insert with check (true);
create policy "anon read" on budgets for select using (true);
create policy "anon write" on budgets for upsert with check (true);
create policy "anon read" on goals for select using (true);
create policy "anon write" on goals for upsert with check (true);
