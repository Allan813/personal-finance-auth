'use client'
import React from 'react'
import { Card } from '@/components/ui'
import { listGoals, upsertGoal } from '@/lib/store'

export default function Goals(){
  const [rows, setRows] = React.useState<any[]>([])
  const [form, setForm] = React.useState({ name:'Reserva de Emergência', target:'50000', saved:'10000', deadline:'2026-03' })

  React.useEffect(()=>{ (async()=> setRows(await listGoals()))() },[])

  async function save(){
    await upsertGoal({ name: form.name, target: Number(form.target), saved: Number(form.saved), deadline: form.deadline })
    setRows(await listGoals())
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
      <Card className="lg:col-span-2" title="Metas">
        <div className="space-y-4">
          {rows.map((g,i)=>{
            const pct = Math.min(100, Math.round((Number(g.saved)/Number(g.target))*100))
            return (
              <div key={i}>
                <div className="flex items-center justify-between text-sm">
                  <div className="font-medium">{g.name}</div>
                  <div className="text-neutral-500">{pct}%</div>
                </div>
                <div className="w-full h-2 bg-neutral-200 rounded-full mt-2">
                  <div className="h-2 bg-black rounded-full" style={{ width: `${pct}%` }} />
                </div>
                <div className="mt-2 text-xs text-neutral-500">{Number(g.saved).toLocaleString('pt-BR',{style:'currency',currency:'BRL'})} de {Number(g.target).toLocaleString('pt-BR',{style:'currency',currency:'BRL'})} • prazo {g.deadline}</div>
              </div>
            )
          })}
        </div>
      </Card>
      <Card title="Nova meta">
        <div className="grid grid-cols-2 gap-2 text-sm">
          <input className="px-3 py-2 rounded-xl border" placeholder="Nome" value={form.name} onChange={e=>setForm({...form, name:e.target.value})} />
          <input className="px-3 py-2 rounded-xl border" placeholder="Alvo" value={form.target} onChange={e=>setForm({...form, target:e.target.value})} />
          <input className="px-3 py-2 rounded-xl border" placeholder="Acumulado" value={form.saved} onChange={e=>setForm({...form, saved:e.target.value})} />
          <input className="px-3 py-2 rounded-xl border" placeholder="Prazo (YYYY-MM)" value={form.deadline} onChange={e=>setForm({...form, deadline:e.target.value})} />
          <button className="col-span-2 px-3 py-2 rounded-xl bg-black text-white" onClick={save}>Salvar</button>
        </div>
      </Card>
    </div>
  )
}
