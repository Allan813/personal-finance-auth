-- Função para gen_random_uuid (se necessário)
-- em projetos novos do Supabase já existe.

create table if not exists transactions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  date date not null,
  amount numeric not null,
  description text,
  category text,
  type text check (type in ('income','expense')) not null,
  inserted_at timestamp with time zone default now()
);

create table if not exists bills (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  amount numeric not null,
  due_day int not null,
  category text,
  autopay boolean default false,
  inserted_at timestamp with time zone default now()
);

create table if not exists budgets (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  month text not null,
  category text not null,
  planned_amount numeric not null,
  inserted_at timestamp with time zone default now(),
  unique(user_id, month, category)
);

create table if not exists goals (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  target numeric not null,
  saved numeric not null,
  deadline text,
  inserted_at timestamp with time zone default now()
);

alter table transactions enable row level security;
alter table bills enable row level security;
alter table budgets enable row level security;
alter table goals enable row level security;

-- Policies: cada usuário só vê/grava o que é seu
create policy "read own" on transactions for select using (auth.uid() = user_id);
create policy "insert own" on transactions for insert with check (auth.uid() = user_id);

create policy "read own" on bills for select using (auth.uid() = user_id);
create policy "insert own" on bills for insert with check (auth.uid() = user_id);

create policy "read own" on budgets for select using (auth.uid() = user_id);
create policy "upsert own" on budgets for insert with check (auth.uid() = user_id);
create policy "update own" on budgets for update using (auth.uid() = user_id) with check (auth.uid() = user_id);

create policy "read own" on goals for select using (auth.uid() = user_id);
create policy "upsert own" on goals for insert with check (auth.uid() = user_id);
create policy "update own" on goals for update using (auth.uid() = user_id) with check (auth.uid() = user_id);
