'use client'
import { supabase } from './supabase'
import { getUser } from './auth'

export type Tx = { id?: string; date: string; amount: number; description: string; category: string; type: 'income'|'expense', user_id?: string }
export type Bill = { id?: string; name: string; amount: number; due_day: number; category: string; autopay: boolean, user_id?: string }
export type Budget = { id?: string; month: string; category: string; planned_amount: number, user_id?: string }
export type Goal = { id?: string; name: string; target: number; saved: number; deadline: string, user_id?: string }

export async function listTransactions(): Promise<Tx[]> {
  const user = await getUser(); if(!user) return []
  const { data } = await supabase.from('transactions').select('*').eq('user_id', user.id).order('date')
  return (data || []) as Tx[]
}
export async function addTransaction(t: Tx) {
  const user = await getUser(); if(!user) return
  return await supabase.from('transactions').insert({ ...t, user_id: user.id })
}

export async function listBills(): Promise<Bill[]> {
  const user = await getUser(); if(!user) return []
  const { data } = await supabase.from('bills').select('*').eq('user_id', user.id).order('due_day')
  return (data || []) as Bill[]
}
export async function addBill(b: Bill) {
  const user = await getUser(); if(!user) return
  return await supabase.from('bills').insert({ ...b, user_id: user.id })
}

export async function listBudgets(): Promise<Budget[]> {
  const user = await getUser(); if(!user) return []
  const { data } = await supabase.from('budgets').select('*').eq('user_id', user.id)
  return (data || []) as Budget[]
}
export async function upsertBudget(b: Budget) {
  const user = await getUser(); if(!user) return
  return await supabase.from('budgets').upsert({ ...b, user_id: user.id }, { onConflict: 'month,category,user_id' })
}

export async function listGoals(): Promise<Goal[]> {
  const user = await getUser(); if(!user) return []
  const { data } = await supabase.from('goals').select('*').eq('user_id', user.id)
  return (data || []) as Goal[]
}
export async function upsertGoal(g: Goal) {
  const user = await getUser(); if(!user) return
  return await supabase.from('goals').upsert({ ...g, user_id: user.id })
}
