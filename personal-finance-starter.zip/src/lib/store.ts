'use client'
import { supabase } from './supabase'

export type Tx = { id?: string; date: string; amount: number; description: string; category: string; type: 'income'|'expense' }
export type Bill = { id?: string; name: string; amount: number; due_day: number; category: string; autopay: boolean }
export type Budget = { id?: string; month: string; category: string; planned_amount: number }
export type Goal = { id?: string; name: string; target: number; saved: number; deadline: string }

const LS = {
  get<T>(k: string, fallback: T): T { try { return JSON.parse(localStorage.getItem(k) || '') as T } catch { return fallback } },
  set<T>(k: string, v: T) { localStorage.setItem(k, JSON.stringify(v)) }
}

// --- Transactions ---
export async function listTransactions(): Promise<Tx[]> {
  if (supabase) {
    const { data } = await supabase.from('transactions').select('*').order('date')
    return (data || []) as Tx[]
  }
  return LS.get<Tx[]>('tx', [])
}
export async function addTransaction(t: Tx) {
  if (supabase) return await supabase.from('transactions').insert(t)
  const arr = await listTransactions(); arr.push(t); LS.set('tx', arr)
}

// --- Bills ---
export async function listBills(): Promise<Bill[]> {
  if (supabase) { const { data } = await supabase.from('bills').select('*').order('due_day'); return data as Bill[] }
  return LS.get<Bill[]>('bills', [])
}
export async function addBill(b: Bill) {
  if (supabase) return await supabase.from('bills').insert(b)
  const arr = await listBills(); arr.push(b); LS.set('bills', arr)
}

// --- Budgets ---
export async function listBudgets(): Promise<Budget[]> {
  if (supabase) { const { data } = await supabase.from('budgets').select('*'); return data as Budget[] }
  return LS.get<Budget[]>('budgets', [])
}
export async function upsertBudget(b: Budget) {
  if (supabase) return await supabase.from('budgets').upsert(b, { onConflict: 'month,category' })
  const arr = await listBudgets(); const i = arr.findIndex(x=>x.month===b.month && x.category===b.category); if(i>=0) arr[i]=b; else arr.push(b); LS.set('budgets', arr)
}

// --- Goals ---
export async function listGoals(): Promise<Goal[]> {
  if (supabase) { const { data } = await supabase.from('goals').select('*'); return data as Goal[] }
  return LS.get<Goal[]>('goals', [])
}
export async function upsertGoal(g: Goal) {
  if (supabase) return await supabase.from('goals').upsert(g)
  const arr = await listGoals(); const i = arr.findIndex(x=>x.name===g.name); if(i>=0) arr[i]=g; else arr.push(g); LS.set('goals', arr)
}
