# Personal Finance — Auth (Next.js + Supabase)

- Login por **link mágico** e **Google** (Supabase Auth)
- Tabelas isoladas por usuário via **RLS (auth.uid())**
- Páginas protegidas com **RequireAuth**

## Rodar local
```bash
npm i
cp .env.example .env.local  # preencha com as chaves do Supabase
npm run dev
```
Acesse http://localhost:3000/login

## Deploy (Vercel)
1. Crie o projeto no Supabase, copie URL e ANON KEY para as variáveis no Vercel.
2. Rode o SQL abaixo no Supabase (SQL Editor).

## SQL (tabelas + RLS)
Veja o arquivo `supabase_auth.sql` no repositório.
