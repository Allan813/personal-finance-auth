'use client'
import React from 'react'
import RequireAuth from '@/components/RequireAuth'

import { Card, CSVButton } from '@/components/ui'
import { listTransactions, addTransaction } from '@/lib/store'

export default function Transactions(){
  const [rows, setRows] = React.useState<any[]>([])

  React.useEffect(()=>{ (async()=> setRows(await listTransactions()))() },[])

  async function onCSV(data:any[]){
    for(const r of data){
      await addTransaction({
        date: r.date || r.data || r.DATA,
        amount: Number(r.amount || r.valor || r.AMOUNT || 0),
        description: r.description || r.merchant || r.DESCRIPTION || '',
        category: r.category || 'Outros',
        type: (r.type || r.TIPO || '').toLowerCase().includes('receita') ? 'income' : (Number(r.amount)<0 ? 'expense' : 'expense')
      })
    }
    setRows(await listTransactions())
  }

  return (
    <RequireAuth>
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold">Transações</h2>
        <CSVButton onRows={onCSV} />
      </div>
      <Card>
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-neutral-500">
              <th className="py-2">Data</th>
              <th className="py-2">Descrição</th>
              <th className="py-2">Categoria</th>
              <th className="py-2 text-right">Valor</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((t,i)=> (
              <tr key={i} className="border-t border-neutral-100">
                <td className="py-2">{t.date}</td>
                <td className="py-2">{t.description}</td>
                <td className="py-2">{t.category}</td>
                <td className="py-2 text-right">{Number(t.amount).toLocaleString('pt-BR',{style:'currency',currency:'BRL'})}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </RequireAuth>
  )
}
