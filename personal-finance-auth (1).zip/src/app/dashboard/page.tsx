'use client'
import React from 'react'
import RequireAuth from '@/components/RequireAuth'

import { Card, Stat, Pill } from '@/components/ui'
import { listTransactions, listBills } from '@/lib/store'
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts'

const PIE = ['#2563eb','#16a34a','#f59e0b','#ef4444','#7c3aed','#0ea5e9','#22c55e','#a855f7']
const currency = (n:number)=> n.toLocaleString('pt-BR',{style:'currency',currency:'BRL'})

export default function Dashboard(){
  const [tx, setTx] = React.useState<any[]>([])
  const [bills, setBills] = React.useState<any[]>([])
  const [month, setMonth] = React.useState<string>(new Date().toISOString().slice(0,7))

  React.useEffect(()=>{ (async()=>{ setTx(await listTransactions()); setBills(await listBills()); })() },[])

  const incomes = tx.filter(t=>t.type==='income')
  const expenses = tx.filter(t=>t.type==='expense')
  const totalIncome = incomes.reduce((a,b)=>a+Number(b.amount||0),0)
  const totalVariable = expenses.reduce((a,b)=>a+Number(b.amount||0),0)
  const totalFixed = bills.reduce((a,b)=>a+Number(b.amount||0),0)
  const net = totalIncome - (totalFixed + totalVariable)

  const byCat = Object.entries(expenses.reduce((acc:any,t:any)=>{ acc[t.category] = (acc[t.category]||0)+Number(t.amount||0); return acc },{}))
    .map(([name, value])=>({ name, value }))

  const daysInMonth = new Date(Number(month.slice(0,4)), Number(month.slice(5,7)), 0).getDate()
  let running = 0
  const series = Array.from({length:daysInMonth}, (_,i)=>{
    const d = `${month}-${String(i+1).padStart(2,'0')}`
    const change = tx.filter(t=>t.date===d).reduce((a,b)=> a + (b.type==='income'?Number(b.amount):-Number(b.amount)), 0)
    const billsToday = bills.filter(b=> String(b.due_day).padStart(2,'0')===d.slice(8)).reduce((a,b)=> a + Number(b.amount),0)
    running += (change - billsToday)
    return { date: d.slice(8), saldo: Math.round(running) }
  })

  return (
    <RequireAuth>
      <div className="flex items-center gap-2 mb-4">
        <input type="month" value={month} onChange={e=>setMonth(e.target.value)} className="px-3 py-2 rounded-xl border border-neutral-200 bg-white text-sm"/>
        <a className="px-3 py-2 rounded-xl bg-black text-white text-sm" href="#" onClick={(e)=>{e.preventDefault(); window.print()}}>Exportar PDF</a>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card title="Entradas (Mês)"><Stat label="Total" value={currency(totalIncome)} /></Card>
        <Card title="Fixas (Mês)"><Stat label="Total" value={currency(totalFixed)} hint={`Contas: ${bills.length}`} /></Card>
        <Card title="Variáveis (Mês)"><Stat label="Total" value={currency(totalVariable)} hint={`${expenses.length} transações`} /></Card>
        <Card title="Resultado (Mês)"><Stat label="Saldo projetado" value={currency(net)} hint={net>=0? 'Sobra':'Ajustar gastos'}/></Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mt-4">
        <Card className="lg:col-span-2" title="Projeção de saldo diário">
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={series} margin={{ left:10, right:10, top:10, bottom:10 }}>
                <XAxis dataKey="date" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip formatter={(v:any)=>currency(Number(v))} labelFormatter={(l)=>`Dia ${l}`}/>
                <Line type="monotone" dataKey="saldo" stroke="#111827" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Card>
        <Card title="Gastos por categoria (variável)">
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={byCat} dataKey="value" nameKey="name" innerRadius={55} outerRadius={90}>
                  {byCat.map((_,i)=>(<Cell key={i} fill={PIE[i%PIE.length]} />))}
                </Pie>
                <Tooltip formatter={(v:any)=>currency(Number(v))} />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
            {byCat.map((c,i)=> (
              <div key={c.name} className="flex items-center gap-2">
                <span className="inline-block w-2.5 h-2.5 rounded-sm" style={{ background: PIE[i%PIE.length] }} />
                <span className="text-neutral-600">{c.name}</span>
                <span className="ml-auto font-medium">{currency(Number(c.value))}</span>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </RequireAuth>
  )
}
