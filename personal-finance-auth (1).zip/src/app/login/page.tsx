'use client'
import React from 'react'
import { supabase } from '@/lib/supabase'

export default function LoginPage(){
  const [email, setEmail] = React.useState('')
  const [msg, setMsg] = React.useState<string>('')

  async function magic(){
    setMsg('Enviando link…')
    const { error } = await supabase.auth.signInWithOtp({ email, options: { emailRedirectTo: (typeof window !== 'undefined' ? window.location.origin : '') + '/dashboard' } })
    setMsg(error ? `Erro: ${error.message}` : 'Link enviado! Verifique seu e-mail.')
  }

  async function google(){
    const { error } = await supabase.auth.signInWithOAuth({ provider: 'google', options: { redirectTo: (typeof window !== 'undefined' ? window.location.origin : '') + '/dashboard' } })
    if(error) setMsg(`Erro: ${error.message}`)
  }

  return (
    <div className="max-w-md mx-auto bg-white/80 p-6 rounded-2xl border">
      <h2 className="text-lg font-semibold mb-2">Entrar</h2>
      <p className="text-sm text-neutral-600 mb-4">Use link mágico por e-mail ou entre com Google.</p>
      <div className="grid gap-2">
        <input className="px-3 py-2 rounded-xl border" placeholder="seu@email"
               value={email} onChange={e=>setEmail(e.target.value)} />
        <button className="px-3 py-2 rounded-xl bg-black text-white" onClick={magic}>Enviar link mágico</button>
        <div className="text-center text-xs text-neutral-400">ou</div>
        <button className="px-3 py-2 rounded-xl bg-neutral-200" onClick={google}>Entrar com Google</button>
      </div>
      {msg && <div className="text-xs text-neutral-600 mt-3">{msg}</div>}
    </div>
  )
}
