'use client'
import React from 'react'
import { getUser } from '@/lib/auth'
import Link from 'next/link'

export default function RequireAuth({ children }:{ children: React.ReactNode }){
  const [loading, setLoading] = React.useState(true)
  const [user, setUser] = React.useState<any>(null)

  React.useEffect(()=>{
    (async()=>{
      const u = await getUser()
      setUser(u)
      setLoading(false)
    })()
  }, [])

  if (loading) return <div className="text-sm text-neutral-500">Carregando…</div>
  if (!user) return (
    <div className="max-w-md mx-auto bg-white/80 p-6 rounded-2xl border text-center">
      <h2 className="text-lg font-semibold mb-2">Você precisa estar logado</h2>
      <p className="text-sm text-neutral-600 mb-4">Acesse sua conta para ver seus dados financeiros.</p>
      <Link href="/login" className="px-4 py-2 rounded-xl bg-black text-white">Ir para Login</Link>
    </div>
  )

  return <>{children}</>
}
