'use client'
import React from 'react'
import Papa from 'papaparse'

export const Card = ({ title, right, className='', children }:{ title?:string, right?:React.ReactNode, className?:string, children:React.ReactNode }) => (
  <div className={`bg-white/70 backdrop-blur p-5 rounded-2xl shadow-sm border border-neutral-100 ${className}`}>
    <div className="flex items-center justify-between mb-3">
      {title ? <h3 className="text-sm font-semibold text-neutral-700">{title}</h3> : <div />}
      {right}
    </div>
    {children}
  </div>
)

export const Stat = ({ label, value, hint }:{label:string, value:string, hint?:string}) => (
  <div>
    <div className="text-xs text-neutral-500">{label}</div>
    <div className="text-xl font-semibold">{value}</div>
    {hint && <div className="text-xs text-neutral-500 mt-1">{hint}</div>}
  </div>
)

export const Pill = ({children}:{children:React.ReactNode}) => (
  <span className="px-2.5 py-1 rounded-full text-xs bg-neutral-100 text-neutral-700">{children}</span>
)

export function CSVButton({onRows}:{onRows:(rows:any[])=>void}){
  const ref = React.useRef<HTMLInputElement>(null)
  return (
    <>
      <button className="px-3 py-2 rounded-xl bg-black text-white text-sm" onClick={()=>ref.current?.click()}>Importar CSV</button>
      <input ref={ref} type="file" accept=".csv" className="hidden" onChange={(e)=>{
        const f = e.target.files?.[0]; if(!f) return;
        Papa.parse(f, { header:true, skipEmptyLines:true, complete:(res)=> onRows(res.data as any[]) })
      }}/>
    </>
  )
}
