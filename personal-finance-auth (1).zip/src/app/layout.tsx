import './globals.css'
import React from 'react'
import Link from 'next/link'
import AuthButton from '@/components/AuthButton'

export const metadata = { title: 'Personal Finance (Auth)', description: 'Dashboard de finanças pessoais com login' }

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR">
      <body className="min-h-screen bg-gradient-to-b from-neutral-50 to-neutral-100 text-neutral-900">
        <header className="px-6 py-5 flex items-center justify-between border-b border-neutral-200/60 bg-white/60 backdrop-blur sticky top-0 z-10">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-2xl bg-black text-white grid place-items-center font-bold">PF</div>
            <div>
              <h1 className="text-lg font-semibold leading-none">Finanças Pessoais</h1>
              <p className="text-xs text-neutral-500">Resumo • Contas • Orçamento • Metas</p>
            </div>
          </div>
          <nav className="flex items-center gap-2 text-sm">
            <Link className="px-3 py-2 rounded-xl hover:bg-black/5" href="/dashboard">Dashboard</Link>
            <Link className="px-3 py-2 rounded-xl hover:bg-black/5" href="/transactions">Transações</Link>
            <Link className="px-3 py-2 rounded-xl hover:bg-black/5" href="/bills">Contas</Link>
            <Link className="px-3 py-2 rounded-xl hover:bg-black/5" href="/budgets">Orçamento</Link>
            <Link className="px-3 py-2 rounded-xl hover:bg-black/5" href="/goals">Metas</Link>
          </nav>
          <AuthButton />
        </header>
        <main className="p-6 max-w-7xl mx-auto">{children}</main>
      </body>
    </html>
  )
}
