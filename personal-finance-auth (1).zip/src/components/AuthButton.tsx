'use client'
import React from 'react'
import { supabase } from '@/lib/supabase'
import Link from 'next/link'

export default function AuthButton(){
  const [user, setUser] = React.useState<any>(null)
  React.useEffect(()=>{
    supabase.auth.getUser().then(({ data })=> setUser(data.user || null))
    const { data: sub } = supabase.auth.onAuthStateChange((_e, session)=> setUser(session?.user || null))
    return ()=>{ sub.subscription.unsubscribe() }
  }, [])

  if (!user) return <Link href="/login" className="px-3 py-2 rounded-xl bg-black text-white text-sm">Entrar</Link>
  return (
    <div className="flex items-center gap-3">
      <span className="text-xs text-neutral-600">{user.email}</span>
      <button
        className="px-3 py-2 rounded-xl bg-neutral-200 text-sm"
        onClick={()=> supabase.auth.signOut() }
      >Sair</button>
    </div>
  )
}
