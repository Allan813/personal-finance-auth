'use client'
import React from 'react'
import { Card } from '@/components/ui'
import { listBudgets, upsertBudget } from '@/lib/store'

export default function Budgets(){
  const [rows, setRows] = React.useState<any[]>([])
  const [form, setForm] = React.useState({ month: new Date().toISOString().slice(0,7), category: 'Alimentação', planned_amount: '' })

  React.useEffect(()=>{ (async()=> setRows(await listBudgets()))() },[])

  async function save(){
    await upsertBudget({ month: form.month, category: form.category, planned_amount: Number(form.planned_amount) })
    setRows(await listBudgets())
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
      <Card className="lg:col-span-2" title="Orçamentos">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-neutral-500">
              <th className="py-2">Mês</th>
              <th className="py-2">Categoria</th>
              <th className="py-2 text-right">Planejado</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((b,i)=> (
              <tr key={i} className="border-t border-neutral-100">
                <td className="py-2">{b.month}</td>
                <td className="py-2">{b.category}</td>
                <td className="py-2 text-right">{Number(b.planned_amount).toLocaleString('pt-BR',{style:'currency',currency:'BRL'})}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
      <Card title="Novo orçamento">
        <div className="grid grid-cols-2 gap-2 text-sm">
          <input className="px-3 py-2 rounded-xl border" type="month" value={form.month} onChange={e=>setForm({...form, month:e.target.value})} />
          <input className="px-3 py-2 rounded-xl border" placeholder="Categoria" value={form.category} onChange={e=>setForm({...form, category:e.target.value})} />
          <input className="px-3 py-2 rounded-xl border" placeholder="Planejado" value={form.planned_amount} onChange={e=>setForm({...form, planned_amount:e.target.value})} />
          <button className="col-span-2 px-3 py-2 rounded-xl bg-black text-white" onClick={save}>Salvar</button>
        </div>
      </Card>
    </div>
  )
}
