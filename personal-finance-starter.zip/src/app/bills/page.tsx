'use client'
import React from 'react'
import { Card } from '@/components/ui'
import { listBills, addBill } from '@/lib/store'

export default function Bills(){
  const [rows, setRows] = React.useState<any[]>([])
  const [form, setForm] = React.useState({ name:'', amount:'', due_day:'', category:'Utilidades', autopay:false })

  React.useEffect(()=>{ (async()=> setRows(await listBills()))() },[])

  async function add(){
    await addBill({ name: form.name, amount: Number(form.amount), due_day: Number(form.due_day), category: form.category, autopay: form.autopay })
    setRows(await listBills())
    setForm({ name:'', amount:'', due_day:'', category:'Utilidades', autopay:false })
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
      <Card className="lg:col-span-2" title="Contas do mês">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-neutral-500">
              <th className="py-2">Conta</th>
              <th className="py-2">Categoria</th>
              <th className="py-2">Vencimento</th>
              <th className="py-2 text-right">Valor</th>
              <th className="py-2 text-right">Status</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((b,i)=> (
              <tr key={i} className="border-t border-neutral-100">
                <td className="py-2">{b.name}</td>
                <td className="py-2">{b.category}</td>
                <td className="py-2">dia {b.due_day}</td>
                <td className="py-2 text-right">{Number(b.amount).toLocaleString('pt-BR',{style:'currency',currency:'BRL'})}</td>
                <td className="py-2 text-right">{b.autopay? 'auto':'manual'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
      <Card title="Adicionar conta">
        <div className="grid grid-cols-2 gap-2 text-sm">
          <input className="px-3 py-2 rounded-xl border" placeholder="Nome" value={form.name} onChange={e=>setForm({...form, name:e.target.value})} />
          <input className="px-3 py-2 rounded-xl border" placeholder="Valor" value={form.amount} onChange={e=>setForm({...form, amount:e.target.value})} />
          <input className="px-3 py-2 rounded-xl border" placeholder="Dia venc." value={form.due_day} onChange={e=>setForm({...form, due_day:e.target.value})} />
          <input className="px-3 py-2 rounded-xl border" placeholder="Categoria" value={form.category} onChange={e=>setForm({...form, category:e.target.value})} />
          <label className="col-span-2 flex items-center gap-2 text-xs"><input type="checkbox" checked={form.autopay} onChange={e=>setForm({...form, autopay:e.target.checked})}/> débito automático</label>
          <button className="col-span-2 px-3 py-2 rounded-xl bg-black text-white" onClick={add}>Salvar</button>
        </div>
      </Card>
    </div>
  )
}
